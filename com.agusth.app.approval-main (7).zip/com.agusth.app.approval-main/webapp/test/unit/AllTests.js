sap.ui.define([
	"comagusthapp/approval/test/unit/controller/Selection.controller"
], function () {
	"use strict";
});
