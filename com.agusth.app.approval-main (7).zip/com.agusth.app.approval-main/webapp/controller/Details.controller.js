sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "sap/ui/model/json/JSONModel",
    "com/agusth/app/approval/utils/formatter",
    "sap/ui/model/Filter",
    "sap/ui/model/FilterOperator",
    'sap/ui/export/Spreadsheet',
    'sap/m/MessageToast',
    "sap/ui/core/routing/History",
    'sap/m/library',
    "sap/m/UploadCollectionParameter",
],
    /**
     * @param {typeof sap.ui.core.mvc.Controller} Controller
     */
    function (Controller, JSONModel, formatter, Filter, FilterOperator, Spreadsheet, MessageToast, History, mobileLibrary, UploadCollectionParameter) {
        "use strict";

        var URLHelper = mobileLibrary.URLHelper;

        return Controller.extend("com.agusth.app.approval.controller.Selection", {
            formatter: formatter,
            onInit: function () {
                this._oRouter = sap.ui.core.UIComponent.getRouterFor(this);
                this._oRouter.attachRouteMatched(this._onRouteMatched, this);
            },

            onNavBack: function () {
                var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
                oRouter.navTo("RouteSelection", {}, true);
            },

            _onRouteMatched: function (oEvent) {
                var params = oEvent.getParameter("arguments");
                var routeName = oEvent.getParameter("name");
                if (routeName === "Details") {
                    this.params = params;
                    this.Pspnr = params.Pspnr;
                    this.Lifnr = params.Lifnr;
                    this.WorksId = params.WorksId;
                    this.PymRespnNo = params.PymRespnNo;
                    this.ZzscpcObjectkey = params.objectKey;
                    this.paymentResId = params.paymentResId;
                    this.onHeaderPdf(params);
                    this.onApproverTable(params);
                    this.onInvoiceTable(params);

                    this.configUpload();
                    this.getView().byId("idIconTabBarMulti").setSelectedKey("Header");
                    this.getView().byId("idBackChargeChecbox").setSelected(false);

                    this.getView().getModel("AppModel").setProperty("/SelectedObject", params);
                    this.defaultRouterSelection();
                }
            },

            defaultRouterSelection: function () {
                this.getView().byId("idCheckAttach").setSelected(false);
                this.getView().byId("idBackChargeChecbox").setSelected(false);
            },

            enableModelfn: function (val) {
                var obj = {
                    enableCheckBox: val
                };
                var json = new sap.ui.model.json.JSONModel(obj);
                this.getView().setModel(json, "EnableModel");
            },


            onHeaderPdf: function (params) {
                var oBusyDialog = new sap.m.BusyDialog();
                oBusyDialog.open();
                var pspnr = params.Pspnr;
                //pspnr = "PM-00.HODTEST";
                var lifnr = params.Lifnr;
                //lifnr = "303080";

                var pymResNo = params.PymRespnNo;
                //pymResNo = "1";
                var worksId = params.WorksId;
                //worksId = "054";
                var aFilter = [];
                aFilter.push(new Filter("Pspnr", FilterOperator.EQ, pspnr));
                aFilter.push(new Filter("Lifnr", FilterOperator.EQ, lifnr));
                aFilter.push(new Filter("ZzscWorksId", FilterOperator.EQ, worksId));
                aFilter.push(new Filter("ZzscPymRespnNo", FilterOperator.EQ, pymResNo));
                aFilter.push(new Filter("ZzscpcObjectkey", FilterOperator.EQ, params.objectKey));
                var HeaderPdf = [], AttachmentPdf = [];

                this.getOwnerComponent().getModel("PaymentResponse").read("/ZSC_PYM_RESPN_AT_SSet", {
                    async: true,
                    filters: aFilter,
                    success: function (oData, Response) {
                        var results = oData.results;
                        for (var i = 0; i < results.length; i++) {
                            if (results[i].ZzscArchDocType === "ZSC_PR_PDF") {
                                HeaderPdf.push(results[i]);
                            } else {
                                AttachmentPdf.push(results[i]);
                            }
                        }
                        var appModel = this.getView().getModel("AppModel");
                        if (HeaderPdf[0]) {
                            this.getView().byId("idPdfViewer").setSource(HeaderPdf[0].ZzscUrl);
                        }
                        AttachmentPdf.totalCount = AttachmentPdf.length;

                        // appModel.setProperty("/HeaderTab", HeaderPdf);
                        appModel.setProperty("/AttachmentTab", AttachmentPdf);
                        this.getView().getModel("AppModel").refresh();
                        oBusyDialog.close();

                    }.bind(this),
                    error: function (Odata, Response) {
                        oBusyDialog.close();
                    }
                });
            },

            onApproverTable: function (params) {
                var oBusyDialog = new sap.m.BusyDialog();
                oBusyDialog.open();
                var pspnr = params.Pspnr;
                var lifnr = params.Lifnr;
                var pymResNo = params.PymRespnNo;
                var workId = params.WorksId;
                var objectKey = params.objectKey;
                var wfId = params.wfId;
                var role = params.role;
                this.role = role;
                var level = params.level;
                this.level = level;
                var approverName = params.approverName;
                this.approverName = approverName;
                var sequence = params.sequence;
                this.sequence = sequence;


                var filters = [];
                filters.push(new Filter("ZzscWorksId", "EQ", workId));
                filters.push(new Filter("ZZSCPC_SEQ", "EQ", sequence));
                filters.push(new Filter("Pspnr", "EQ", pspnr));
                filters.push(new Filter("Lifnr", "EQ", lifnr));
                filters.push(new Filter("ZzscPymRespnNo", "EQ", pymResNo));
                filters.push(new Filter("ZzscpcObjectkey", "EQ", objectKey));
                filters.push(new Filter("ZzscpcWfid", "EQ", wfId));
                filters.push(new Filter("ZzscpcRole", "EQ", role));
                filters.push(new Filter("ZzscpcLevel", "EQ", level));
                filters.push(new Filter("ZzscpcApprover", "EQ", approverName));

                this.getOwnerComponent().getModel("PaymentResponse").read("/ZSC_PC_APPR_SSet", {
                    async: true,
                    filters: filters,
                    success: function (oData, Response) {
                        let results = oData.results;
                        let approveData = [];
                        if (results) {
                            approveData = results.filter(function (val) {
                                return val.ZzscpcApprover === this.approverName && val.ZzscpcRole === this.role && val.ZzscpcLevel === this.level
                            }.bind(this));

                        }
                        var appModel = this.getView().getModel("AppModel");
                        appModel.setProperty("/ApproverTable", results);
                        appModel.setProperty("/ApproverComment", approveData);
                        oBusyDialog.close();

                    }.bind(this),
                    error: function (Odata, Response) {
                        oBusyDialog.close();
                    }
                });
            },

            onInvoiceTable: function (params) {
                var oBusyDialog = new sap.m.BusyDialog();
                oBusyDialog.open();
                var pspnr = params.Pspnr;
                var lifnr = params.Lifnr;
                var pymResNo = params.PymRespnNo;
                var worksId = params.WorksId;

                var filters = [];
                filters.push(new Filter("Pspnr", "EQ", pspnr));
                filters.push(new Filter("Lifnr", "EQ", lifnr));
                filters.push(new Filter("ZzscWorksId", "EQ", worksId));
                filters.push(new Filter("ZzscPymRespnNo", "EQ", pymResNo));
                filters.push(new Filter("ZzscPymRespnId", "EQ", params.paymentResId));

                this.getOwnerComponent().getModel("PaymentResponse").read("/zsc_backchargeSet", {
                    filters: filters,
                    async: true,
                    success: function (oData, Response) {
                        var results = oData.results;
                        var appModel = this.getView().getModel("AppModel");
                        appModel.setProperty("/InvoiceTable", results);
                        appModel.setProperty("/InvoiceTable/TotalCount", results.length);
                        oBusyDialog.close();
                        if (results.length > 0) {
                            this.enableCheckBoxFn(results);
                        } else {
                            this.enableModelfn(false);
                        }
                    }.bind(this),
                    error: function (Odata, Response) {
                        oBusyDialog.close();
                    }
                });
            },

            enableCheckBoxFn: function (results) {
                if (results) {
                    if (results[0].Authorised !== "") {
                        this.enableModelfn(true);
                    } else {
                        this.enableModelfn(false);
                    }
                }
            },

            onLinkClick: function (oEvent) {
                var href = oEvent.getSource().getTarget();
                URLHelper.redirect(href, true);
            },

            onSkipSelect: function (oEvent) {
                let selectedData = oEvent.getSource().getBindingContext("AppModel").getObject();
                if (oEvent.getSource().getSelected() && (selectedData.Zzscpcpos === "C" || selectedData.Zzscpcpos === "D")) {
                    let skipSelection = this.checkSkipSelection(selectedData);
                    oEvent.getSource().setSelected(skipSelection);
                }

                if (oEvent.getSource().getSelected()) {
                    oEvent.getSource().getBindingContext("AppModel").getObject().ZzscSkip = "X";
                } else {
                    oEvent.getSource().getBindingContext("AppModel").getObject().ZzscSkip = "";
                }
            },

            checkSkipSelection: function (selectedData) {
                let appModel = this.getView().getModel("AppModel");
                let approverTableData = appModel.getProperty("/ApproverTable");
                if (selectedData.Zzscpcpos === "C") {
                    let directorData = approverTableData.filter(val => val.Zzscpcpos === "D");
                    if (directorData && directorData[0].ZzscSkip === "X") {
                        MessageToast.show("Either Director or CEO can be skipped, please uncheck Director to select CEO.");
                        return false;
                    } else {
                        return true;
                    }
                }
                if (selectedData.Zzscpcpos === "D") {
                    let ceoData = approverTableData.filter(val => val.Zzscpcpos === "C");
                    if (ceoData && ceoData[0].ZzscSkip === "X") {
                        MessageToast.show("Either Director or CEO can be skipped, please uncheck CEO to select Director.");
                        return false;
                    } else {
                        return true;
                    }
                }

            },

            updateAprroverEnrty: function () {
                var table = this.getView().byId("idApproverTable");
                var tableDataInvoice = table.getModel("AppModel").getProperty("/InvoiceTable");
                if (tableDataInvoice) {
                    var oEntry = tableDataInvoice[0];
                    delete oEntry.Approver;
                    delete oEntry.__metadata;
                    oEntry.Approved = "X"
                    var params = "Pspnr='" + this.Pspnr + "',Lifnr='" + this.Lifnr + "',ZzscWorksId='" + this.WorksId + "',ZzscPymRespnNo='" + this.PymRespnNo + "',ZzscPymRespnId='" + this.paymentResId + "'";
                    this.getOwnerComponent().getModel("PaymentResponse").update("/zsc_backchargeSet(" + params + ")", oEntry, null, function () {

                    }, function (error) {

                    });
                }
            },

            handleBackChargeApproval: function (buttonType) {
                var checkBox = this.getView().byId("idBackChargeChecbox");
                if (checkBox.getEnabled()) {
                    if (checkBox.getSelected()) {
                        if (buttonType === "Reject") {
                            new sap.m.MessageBox.error("Please uncheck click here to Approve Back charge to Reject");
                            this.backCharge = false;
                        } else {
                            this.backCharge = true;
                            this.callUpdateAprroverEnrty = true;
                        }

                    } else {
                        if (buttonType === "Reject") {
                            this.backCharge = true;
                        } else {
                            new sap.m.MessageBox.error("Please select the checkbox to approve back charge invoice");
                            this.backCharge = false;
                        }
                    }

                } else {
                    this.backCharge = true;
                }

            },

            onApproverRejectPress: function (oEvent) {
                var eventSource = oEvent.getSource();
                var buttonType = eventSource.getType();
                if (buttonType === "Accept") {
                    var messgaseText = "Do you want to Approve this?";
                    var selected = this.getView().byId("idCheckAttach").getSelected();
                    if (!selected) {
                        sap.m.MessageBox.show(
                            "Please View Attachments",
                            sap.m.MessageBox.Icon.ERROR,
                            "Error");

                        return;
                    }
                } else {
                    messgaseText = "Do you want to Reject this?";
                }
                sap.m.MessageBox.confirm(
                    messgaseText,
                    {
                        onClose: function (sAction) {
                            if (sAction === "OK") {
                                this.onApproveRejectPopupPress(oEvent, eventSource);
                            }
                        }.bind(this)
                    });
            },

            onApproveRejectPopupPress: function (oEvent, eventSource) {
                this.callUpdateAprroverEnrty = false;
                this.getView().setBusy(true);
                this.getView().setBusyIndicatorDelay(0);

                var buttonType = eventSource.getType();

                this.handleBackChargeApproval(buttonType);
                // if (this.getView().byId("idIconTabBarMulti").getSelectedKey() === "Invoices") {
                //     this.handleBackChargeApproval(buttonType);
                // } else {
                //     this.backCharge = true;
                // }

                if (!this.backCharge) {
                    this.getView().setBusy(false);
                    return;
                }
                // return;
                var oEntryApprove = [];
                var oEntrySkipApprover = [];
                var table = this.getView().byId("idApproverTable");
                var tableData = table.getModel("AppModel").getData().ApproverTable;

                var approverName = this.approverName,
                    role = this.role,
                    level = this.level;

                if (tableData) {
                    oEntryApprove = tableData.filter(function (val) {
                        return val.ZzscpcApprover.trim() === approverName && val.ZzscpcRole.trim() === role && val.ZzscpcLevel.trim() === level
                    })[0];
                }
                if (tableData) {
                    oEntrySkipApprover = tableData.filter(function (val) {
                        return val.ZzscSkip === "X"
                    });
                }

                this.updateSkipApprover(oEntrySkipApprover, oEntryApprove, eventSource);
            },

            updateSkipApprover: function (oEntrySkipApprover, oEntryApprove, eventSource) {
                this.getOwnerComponent().getModel("PaymentResponse").setUseBatch(false);
                this.getOwnerComponent().getModel("PaymentResponse").setDeferredGroups(["app"]);
                let promiseArr = [];
                let oModel = this.getOwnerComponent().getModel("PaymentResponse");
                for (var i = 0; i < oEntrySkipApprover.length; i++) {
                    delete oEntrySkipApprover[i].ZzscpcCdate;
                    delete oEntrySkipApprover[i].ZzscpcCtime;
                    delete oEntrySkipApprover[i].__metadata;

                    let params = "ZzscpcObjectkey='" + oEntrySkipApprover[i].ZzscpcObjectkey + "',ZzscpcWfid='" + oEntrySkipApprover[i].ZzscpcWfid + "',ZzscpcRole='" + oEntrySkipApprover[i].ZzscpcRole + "',ZzscpcLevel='" + oEntrySkipApprover[i].ZzscpcLevel + "',Pspnr='" + encodeURIComponent(oEntrySkipApprover[i].Pspnr) + "',Lifnr='" + oEntrySkipApprover[i].Lifnr + "',ZzscWorksId='" + oEntrySkipApprover[i].ZzscWorksId + "',ZZSCPC_SEQ='" + this.sequence + "',ZzscPymRespnNo='" + oEntrySkipApprover[i].ZzscPymRespnNo + "'";
                    let prom = new Promise((resolve, reject) => {
                        oModel.update("/ZSC_PC_APPR_SSet(" + params + ")", oEntrySkipApprover[i], {
                            method: "PUT",
                            success: function (data) {
                                resolve(data);
                            },
                            error: function (error) {
                                reject(error);
                            }
                        });
                    })
                    promiseArr.push(prom);

                }
                Promise.allSettled(promiseArr).then(() => {
                    this.updateApprover(oEntryApprove, eventSource);
                });

            },

            updateApprover: function (oEntryApprove, eventSource) {
                if (oEntryApprove) {
                    delete oEntryApprove.ZzscpcCdate;
                    delete oEntryApprove.ZzscpcCtime;
                    if (eventSource.getText() === "Approve") {
                        oEntryApprove.ZzscpcAppstat = 'A';
                    } else if (eventSource.getText() === "Reject") {
                        oEntryApprove.ZzscpcAppstat = 'R';
                    }
                    // var params = "ZzscpcObjectkey='116',ZzscpcWfid='0000000135',ZzscpcRole='QS',ZzscpcLevel='00001',Pspnr='0000000013',Lifnr='0000303080',ZzscWorksId='054',ZzscPymRespnNo='1'";

                    var params = "ZzscpcObjectkey='" + oEntryApprove.ZzscpcObjectkey + "',ZzscpcWfid='" + oEntryApprove.ZzscpcWfid + "',ZzscpcRole='" + oEntryApprove.ZzscpcRole + "',ZzscpcLevel='" + oEntryApprove.ZzscpcLevel + "',Pspnr='" + encodeURIComponent(oEntryApprove.Pspnr) + "',Lifnr='" + oEntryApprove.Lifnr + "',ZzscWorksId='" + oEntryApprove.ZzscWorksId + "',ZZSCPC_SEQ='" + this.sequence + "',ZzscPymRespnNo='" + oEntryApprove.ZzscPymRespnNo + "'";

                    this.getOwnerComponent().getModel("PaymentResponse").update("/ZSC_PC_APPR_SSet(" + params + ")",
                        oEntryApprove,
                        {
                            success: function (oData, Response) {
                                this.getView().setBusy(false);
                                if (this.callUpdateAprroverEnrty) {
                                    this.updateAprroverEnrty();
                                }
                                var successObj = JSON.parse(Response.headers["sap-message"]);
                                var successMessage = successObj.message;
                                var resultType = successObj.severity;

                                sap.m.MessageBox.show(
                                    successMessage,
                                    {
                                        title: (resultType === "error") ? "Error" : "Success",
                                        icon: (resultType === "error") ? sap.m.MessageBox.Icon.ERROR : sap.m.MessageBox.Icon.SUCCESS,
                                        actions: [sap.m.MessageBox.Action.OK],
                                        onClose: function (sAction) {
                                            if (resultType !== "error") {
                                                var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
                                                oRouter.navTo("RouteSelection", {}, true);
                                                const bus = this.getOwnerComponent().getEventBus();
                                                bus.publish("channelSelection", "awesomeEvent");
                                            }

                                        }.bind(this)
                                    });

                            }.bind(this),
                            error: function (oData, Respons) {
                                this.getView().setBusy(false);
                                var errorObj = JSON.parse(oData.responseText);
                                var errorMessage = errorObj.error.innererror.errordetails[0].message;
                                sap.m.MessageBox.show(
                                    errorMessage,
                                    sap.m.MessageBox.Icon.ERROR,
                                    "Error");

                            }.bind(this)
                        });
                } else {
                    this.getView().setBusy(false);
                    var errorMessage = "Open item does not matched";
                    sap.m.MessageBox.show(
                        errorMessage,
                        sap.m.MessageBox.Icon.ERROR,
                        "Error");
                }

            },

            configUpload: function (oEvent) {
                var oUploadCollection = this.getView().byId('UploadCollection');
                oUploadCollection.setUploadUrl("/sap/opu/odata/sap/ZSC_PC_PAYMENT_RESPONSE_SRV/ZSC_PYM_RESPN_AT_SSet");
                var oModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZSC_PC_PAYMENT_RESPONSE_SRV", false);
                this.getView().setModel(oModel, "FileUpload");
            },

            onBeforeUploadStarts: function (oEvent) {
                this.getView().setBusyIndicatorDelay(0);
                this.getView().setBusy(true);

                var oCustomerHeaderSlug = new sap.m.UploadCollectionParameter({
                    name: "slug",
                    value: encodeURIComponent(oEvent.getParameter("fileName"))
                });

                var Pspnr = new sap.m.UploadCollectionParameter({
                    name: "Pspnr",
                    value: this.Pspnr
                });
                var Lifnr = new sap.m.UploadCollectionParameter({
                    name: "Lifnr",
                    value: this.Lifnr
                });
                var ZzscWorksId = new sap.m.UploadCollectionParameter({
                    name: "ZzscWorksId",
                    value: this.WorksId
                });
                var ZzscPymRespnNo = new sap.m.UploadCollectionParameter({
                    name: "ZzscPymRespnNo",
                    value: this.PymRespnNo
                });
                var ZzscpcObjectkey = new sap.m.UploadCollectionParameter({
                    name: "ZzscpcObjectkey",
                    value: this.ZzscpcObjectkey
                });
                oEvent.getParameters().addHeaderParameter(oCustomerHeaderSlug);
                oEvent.getParameters().addHeaderParameter(Pspnr);
                oEvent.getParameters().addHeaderParameter(Lifnr);
                oEvent.getParameters().addHeaderParameter(ZzscWorksId);
                oEvent.getParameters().addHeaderParameter(ZzscPymRespnNo);
                oEvent.getParameters().addHeaderParameter(ZzscpcObjectkey);

                var oModel = this.getOwnerComponent().getModel("PaymentResponse");

                oModel.refreshSecurityToken();

                var oHeaders = oModel.oHeaders;

                var sToken = oHeaders['x-csrf-token'];

                var oCustomerHeaderToken = new sap.m.UploadCollectionParameter({
                    name: "x-csrf-token",
                    value: sToken
                });
                oEvent.getParameters().addHeaderParameter(oCustomerHeaderToken);
            },

            onUploadComplete: function (oEvent) {
                this.onHeaderPdf(this.params);
                this.getView().setBusy(false);
            }

        });
    });
