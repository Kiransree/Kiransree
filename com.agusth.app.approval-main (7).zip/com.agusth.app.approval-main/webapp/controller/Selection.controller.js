sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "sap/ui/model/json/JSONModel",
    "com/agusth/app/approval/utils/formatter",
    "sap/ui/model/Filter",
    "sap/ui/model/FilterOperator",
    'sap/ui/export/Spreadsheet',
    'sap/m/MessageToast',
    'sap/ui/core/Fragment'
],
    /**
     * @param {typeof sap.ui.core.mvc.Controller} Controller
     */
    function (Controller, JSONModel, formatter, Filter, FilterOperator, Spreadsheet, MessageToast, Fragment) {
        "use strict";

        return Controller.extend("com.agusth.app.approval.controller.Selection", {
            formatter: formatter,
            onInit: function () {
                if (!this.getView().getModel("SelectionModel")) {
                    this.getView().setModel(new JSONModel({}), "SelectionModel");
                }
                const bus = this.getOwnerComponent().getEventBus();
                bus.subscribe("channelSelection", "awesomeEvent", this.callSelection, this);
                this.onApplicationLoad();

            },
            getResourceText: function (text) {
                return this.getView().getModel("i18n").getResourceBundle().getText(text);

            },
            callSelection: function (channelId, eventId, parametersMap) {
                this.onApplicationLoad();
            },

            onApplicationLoad: function (oEvent) {
                var oBusyDialog = new sap.m.BusyDialog();
                oBusyDialog.open();
                this.getOwnerComponent().getModel("PaymentResponse").read("/ZSC_PC_USER_OPEN_PYM_RSPNSet", {
                    async: true,
                    success: function (oData, Response) {
                        var results = oData.results;
                        var selectionModel = this.getView().getModel("SelectionModel");
                        selectionModel.setProperty("/SelectionRecord", results);
                        selectionModel.setProperty("/TotalSelectionRecord", results.length);

                        var siteCode = this.uniqueBy(results, "ZZSITECD");
                        var projectTitle = this.uniqueBy(results, "PSPNR");
                        var subconName = this.uniqueBy(results, "NAME");
                        selectionModel.setProperty("/SelectionRecord/filer1", siteCode);
                        selectionModel.setProperty("/SelectionRecord/filer2", projectTitle);
                        selectionModel.setProperty("/SelectionRecord/filer3", subconName);

                        oBusyDialog.close();

                    }.bind(this),
                    error: function (Odata, Response) {
                        oBusyDialog.close();
                        new sap.m.MessageBox.error(Odata.message);
                    }
                });
            },

            uniqueBy: function (array, prop) {
                var result = [];
                for (var len = array.length, i = 0; i < len; ++i) {
                    var property = array[i][prop];
                    if (result.indexOf(property) > -1) {
                        continue;
                    }
                    result.push(property);
                }

                var finalResult = result.map(function (arr) {
                    var obj = {
                        [prop]: arr
                    }
                    return obj;
                })
                return finalResult;
            },

            onFilterChange: function (oEvent) {

            },
            onFilterSelectionChange: function (oEvent) {
                // var searchValue = oEvent.getSource().getSelectedKey();

                var filters = [];


                var selectedSite = this.getView().byId("FilterBar").getFilterGroupItems()[0].getControl().getSelectedKey()
                var selectedProject = this.getView().byId("FilterBar").getFilterGroupItems()[1].getControl().getSelectedKey()
                var selectedSub = this.getView().byId("FilterBar").getFilterGroupItems()[2].getControl().getSelectedKey()

                // if (searchValue.trim() != '') {

                var filterSiteCode = new Filter("ZZSITECD", FilterOperator.Contains, selectedSite);
                var filterProjectTitle = new Filter("PSPNR", FilterOperator.Contains, selectedProject);
                var filterSubContractor = new Filter("NAME", FilterOperator.Contains, selectedSub);

                filters = [filterSiteCode, filterProjectTitle, filterSubContractor];

                var finalFilter = new sap.ui.model.Filter({ filters: filters, and: true });

                this.getView().byId("SelectionTable").getBinding().filter(finalFilter);
                // } else {
                //     this.getView().byId("SelectionTable").getBinding().filter([]);
                // }

                // To set the header count
                var length = this.getView().byId("SelectionTable").getBinding().getLength();
                var selectionModel = this.getView().getModel("SelectionModel");
                selectionModel.setProperty("/TotalSelectionRecord", length);
                selectionModel.refresh();
            },

            createColumnConfig: function () {
                return [
                    {
                        label: this.getResourceText("SiteCode"),
                        property: 'ZZSITECD',
                        type: 'number',
                        scale: 0
                    },
                    {
                        label: this.getResourceText("SubContractorName"),
                        property: 'NAME',
                        width: '25'
                    },
                    {
                        label: this.getResourceText("SubContractWork"),
                        property: 'ZZSC_WORKS_TITLE',
                        width: '25'
                    },
                    {
                        label: this.getResourceText("ResponseNumber"),
                        property: 'ZZSC_PYM_RESPN_NO',
                        width: '25'
                    },
                    {
                        label: this.getResourceText("ResponseAmount"),
                        property: 'ZZSC_RESPN_AMT_CURR1',
                        width: '25'
                    },
                    {
                        label: this.getResourceText("UrgentIndicator"),
                        property: 'ZZSC_URGENT_PYM_IND',
                        width: '25'
                    },
                    {
                        label: this.getResourceText("DueDate"),
                        property: 'ZZSC_CLAIM_PERIOD_FROM',
                        width: '25'
                    },
                    {
                        label: this.getResourceText("ClaimPeriodFrom"),
                        property: 'ZZSC_CLAIM_PERIOD_FROM',
                        width: '25'
                    },
                    {
                        label: this.getResourceText("ClaimPeriodTo"),
                        property: 'ZZSC_CLAIM_PERIOD_TO',
                        width: '25'
                    },
                    {
                        label: this.getResourceText("ResponseDate"),
                        property: 'ZZSC_PYM_RESPN_DATE',
                        width: '25'
                    }
                ];
            },

            onExport: function () {
                var aCols, aProducts, oSettings, oSheet;

                aCols = this.createColumnConfig();
                aProducts = this.getView().getModel("SelectionModel").getProperty('/SelectionRecord');

                oSettings = {
                    workbook: { columns: aCols },
                    dataSource: aProducts
                };

                oSheet = new Spreadsheet(oSettings);
                oSheet.build()
                    .then(function () {
                        MessageToast.show('Spreadsheet export has finished');
                    })
                    .finally(function () {
                        oSheet.destroy();
                    });
            },

            onDialogClose: function () {
                this._pDialogRemark.then((dialog => {
                    dialog.close();
                    this.nagivationToDetail(this.selectedObject);
                }));
            },

            openRemarkDialog: function (bindingContext) {
                let selectIndexPath = bindingContext.sPath.lastIndexOf('/') + 1,
                    SelectedIndex = bindingContext.sPath.substr(selectIndexPath),
                    bindElementPath = "SelectionModel>/SelectionRecord/" + SelectedIndex;

                let oView = this.getView();
                if (!this._pDialogRemark) {
                    this._pDialogRemark = Fragment.load({
                        id: oView.getId(),
                        name: "com.agusth.app.approval.fragments.RemarkPopover",
                        controller: this
                    }).then(function (oPopover) {
                        oView.addDependent(oPopover);
                        return oPopover;
                    });
                }
                this._pDialogRemark.then(function (oPopover) {
                    oPopover.bindElement(bindElementPath);
                    oPopover.open();
                });
            },

            loadDetailPage: function (oEvent) {
                let bindingContext = oEvent.getSource().getBindingContext("SelectionModel"),
                    selectedObject = bindingContext.getProperty();

                if (selectedObject.ZZSC_URGENT_PYM_IND === "X") {
                    this.selectedObject = selectedObject;
                    this.openRemarkDialog(bindingContext);
                    return;
                } else {
                    this.nagivationToDetail(selectedObject);
                }
            },

            nagivationToDetail: function (selectedObject) {
                var Pspnr = selectedObject.PSPNR ? selectedObject.PSPNR : "";
                var Lifnr = selectedObject.LIFNR ? selectedObject.LIFNR : "";
                var PymRespnNo = selectedObject.ZZSC_PYM_RESPN_NO ? selectedObject.ZZSC_PYM_RESPN_NO : "";
                var WorksId = selectedObject.ZZSC_WORKS_ID ? selectedObject.ZZSC_WORKS_ID : "";
                var objectKey = selectedObject.ZZSCPC_OBJECTKEY ? selectedObject.ZZSCPC_OBJECTKEY : "";
                var wfId = selectedObject.ZZSCPC_WFID ? selectedObject.ZZSCPC_WFID : "";
                var role = selectedObject.ZZSCPC_ROLE ? selectedObject.ZZSCPC_ROLE : "";
                var level = selectedObject.ZZSCPC_LEVEL ? selectedObject.ZZSCPC_LEVEL : "";
                var approverName = selectedObject.ZZSCPC_APPROVER ? selectedObject.ZZSCPC_APPROVER : "";
                var siteCd = selectedObject.ZZSITECD ? selectedObject.ZZSITECD : "";
                var subName = selectedObject.NAME ? selectedObject.NAME : "";
                var sequence = selectedObject.ZZSCPC_SEQUENCE ? selectedObject.ZZSCPC_SEQUENCE : "";
                var resAmt = selectedObject.ZZSC_RESPN_AMT_CURR1 ? selectedObject.ZZSC_RESPN_AMT_CURR1 : "";
                var claimPerFr = JSON.parse(JSON.stringify(selectedObject.ZZSC_CLAIM_PERIOD_FROM));
                var paymentResId = selectedObject.ZZSC_PYM_RESPN_ID ? selectedObject.ZZSC_PYM_RESPN_ID : "";

                var claimPerTo = JSON.parse(JSON.stringify(selectedObject.ZZSC_CLAIM_PERIOD_TO));

                var dueDate = JSON.parse(JSON.stringify(selectedObject.ZZSC_PYM_RESPN_DATE));

                var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
                oRouter.navTo("Details", {
                    Pspnr: Pspnr,
                    Lifnr: Lifnr,
                    PymRespnNo: PymRespnNo,
                    WorksId: WorksId,
                    objectKey: objectKey,
                    wfId: wfId,
                    role: role,
                    level: level,
                    approverName: approverName,
                    siteCd: siteCd,
                    subName: subName,
                    sequence: sequence,
                    paymentResId: paymentResId,
                    resAmt: resAmt,
                    claimPerFr: claimPerFr,
                    claimPerTo: claimPerTo,
                    dueDate: dueDate
                }
                );
            }

        });
    });
