sap.ui.define([],
    function () {
        return {
            DisplayDateFormat: function (date) {
                if (date) {
                    var dateFormat = sap.ui.core.format.DateFormat.getDateInstance({ pattern: "dd.MM.yyyy" });
                    var dateStr = dateFormat.format(new Date(date));
                    return dateStr;
                }
            },

            SetTableHeader: function (data) {
                if (data) {
                    var record = `Records (${data})`;
                    return record;
                }
            },

            NegativeValue: function (value) {
                if (value && parseInt(value) < 0) {
                    return `(${Math.abs(parseFloat(value.replace(/,/g, '')))})`;
                } else {
                    return value;
                }
            }
        };
    });