## Application Details
|               |
| ------------- |
|**Generation Date and Time**<br>Tue Mar 15 2022 16:35:24 GMT+0530 (India Standard Time)|
|**App Generator**<br>@sap/generator-fiori|
|**App Generator Version**<br>1.4.7|
|**Generation Platform**<br>Visual Studio Code|
|**Floorplan Used**<br>simple|
|**Service Type**<br>OData Url|
|**Service URL**<br>http://34.87.176.203:8000/sap/opu/odata/sap/ZSC_USER_RECORDS_SRV
|**Module Name**<br>approval|
|**Application Title**<br>Selection|
|**Namespace**<br>com.agusth.app|
|**UI5 Theme**<br>sap_fiori_3|
|**UI5 Version**<br>1.65.0|
|**Enable Code Assist Libraries**<br>False|
|**Add Eslint configuration**<br>False|
|**Enable Telemetry**<br>True|

## approval

A Fiori application.

### Starting the generated app

-   This app has been generated using the SAP Fiori tools - App Generator, as part of the SAP Fiori tools suite.  In order to launch the generated app, simply run the following from the generated app root folder:

```
    npm start
```

#### Pre-requisites:

1. Active NodeJS LTS (Long Term Support) version and associated supported NPM version.  (See https://nodejs.org)


# Approval
